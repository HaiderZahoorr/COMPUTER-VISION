# Lab 02 — Effect of Image Filtering on Skin-Lesion Classification

## Contents
- `notebook.ipynb` — complete experimental code
- `results_table.csv` — comparison table (3 models × 6 filter conditions)
- `plots/` — class distribution, filter examples, training curves, confusion matrices

## Sections in the Notebook
1. Dataset Preparation
2. Model Loading
3. Baseline Experiment
4. Image Filtering
5. Training
6. Evaluation
7. Visualization
8. Comparative Analysis

## How to Run
1. Open `notebook.ipynb` in Google Colab.
2. Run all cells in order, top to bottom.
3. When prompted, authenticate with Kaggle (via `kagglehub`) to download the HAM10000 dataset.
4. Adjust `EPOCHS` and the dataset subset size if you want a faster test run.
5. Results are saved to `results_table.csv`; plots are saved as `.png` files.

## Environment
Python 3, PyTorch, torchvision, OpenCV, scikit-learn, pandas, matplotlib, seaborn.
Recommended: Colab GPU runtime (T4).
